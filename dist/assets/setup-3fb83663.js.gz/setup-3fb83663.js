import{a_ as t}from"./layout-9649e413.js";const o={setup(){t.setup({timeout:"500-1000"})}};export{o as default};
