import{a_ as t}from"./layout-15756e35.js";const o={setup(){t.setup({timeout:"500-1000"})}};export{o as default};
