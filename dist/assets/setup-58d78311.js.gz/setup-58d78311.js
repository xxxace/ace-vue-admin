import{a$ as t}from"./layout-c1abb15b.js";const o={setup(){t.setup({timeout:"500-1000"})}};export{o as default};
